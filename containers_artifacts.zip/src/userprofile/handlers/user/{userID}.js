'use strict';
var dataProvider = require('../../data/user/{userID}.js');
/**
 * Operations on /user/{userID}
 */
module.exports = {
    /**
     * summary: 
     * description: Get a User Profile by ID
     * parameters: 
     * produces: 
     * responses: 200, default
     */
    get: function userGET(req, res, next) {
        /**
         * Get the data for response 200
         * For response `default` status 200 is used.
         */
        var status = 200;
        var provider = dataProvider['get']['200'];
        provider(req, res, function (err, data) {
            if (err) {
                next(err);
                return;
            }
            res.status(status).send(data && data.responses);
        });
    },
    /**
     * summary: 
     * description: Declares and creates a new profile
     * parameters: _profile
     * produces: 
     * responses: 201, default
     */
    post: function userPOST(req, res, next) {
        /**
         * Get the data for response 201
         * For response `default` status 200 is used.
         */
        var status = 201;
        var provider = dataProvider['post']['201'];
        provider(req, res, function (err, data) {
            if (err) {
                next(err);
                return;
            }
            res.status(status).send(data && data.responses);
        });
    },
    /**
     * summary: 
     * description: Update User
     * parameters: 
     * produces: 
     * responses: 200, 404, default
     */
    patch: function updateUser(req, res, next) {
        /**
         * Get the data for response 200
         * For response `default` status 200 is used.
         */
        var status = 200;
        var provider = dataProvider['patch']['200'];
        provider(req, res, function (err, data) {
            if (err) {
                next(err);
                return;
            }
            res.status(status).send(data && data.responses);
        });
    },
    /**
     * summary: 
     * description: Delete User By ID
     * parameters: 
     * produces: 
     * responses: 204, 404, default
     */
    delete: function userDELETE(req, res, next) {
        /**
         * Get the data for response 204
         * For response `default` status 200 is used.
         */
        var status = 204;
        var provider = dataProvider['delete']['204'];
        provider(req, res, function (err, data) {
            if (err) {
                next(err);
                return;
            }
            res.status(status).send(data && data.responses);
        });
    }
};
