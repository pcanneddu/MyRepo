
# But First, Containers

## Building and Testing

    cp dockerfiles/Dockerfile_0 src/user-java/Dockerfile
    cp dockerfiles/Dockerfile_1 src/tripviewer/Dockerfile
    cp dockerfiles/Dockerfile_2 src/userprofile/Dockerfile
    cp dockerfiles/Dockerfile_3 src/poi/Dockerfile
    cp dockerfiles/Dockerfile_4 src/trips/Dockerfile

    cd src/user-java/
    docker build .
    cd -

    cd src/tripviewer/
    docker build .
    cd -

    cd src/userprofile/
    docker build .
    cd -

    cd src/poi/
    docker build .
    cd -

    cd src/trips/
    docker build .
    cd -

    docker run -e "ACCEPT_EULA=Y" -e "MSSQL_SA_PASSWORD=yourStrongPassword.123" -p 1433:1433 -d mcr.microsoft.com/mssql/server:2017-latest

    docker login registryrdz9621.azurecr.io
    # User  / Password : registryrdz9621 / 3qzLa6AeB6F0QwguQrsmh4ot2OYcYjZ7YMarKXvApx+ACRBbStN/
    docker pull registryrdz9621.azurecr.io/dataload:1.0
    docker run --network <networkname> -e SQLFQDN=mssql -e SQLUSER=sa -e SQLPASS=yourStrongPassword.123 -e SQLDB=mydrivingDB registryrdz9621.azurecr.io/dataload:1.0

    docker compose exec -it mssql /opt/mssql-tools/bin/sqlcmd -S localhost -U sa -P yourStrongPassword.123
    1> CREATE DATABASE mydrivingDB;
    2> GO


    docker compose build
    docker compose up -d --remove-orphans

    curl http://localhost:8080/api/poi/healthcheck
    curl http://localhost:8081/api/trips/healthcheck
    curl http://localhost:8082/api/tripviewer/healthcheck
    curl http://localhost:8083/api/user-java/healthcheck
    curl http://localhost:8084/api/user-profile/healthcheck

    docker compose down -v --remove-orphans
    docker compose push

# Getting Ready for Orchestration

    az login --use-device-code
    sudo az aks install-cli
    az aks get-credentials --resource-group teamResources --name aks

    kubectl version
    kubectl get nodes

    curl -L https://github.com/kubernetes/kompose/releases/download/v1.28.0/kompose-linux-amd64 -o kompose
    chmod a+x kompose
    sudo mv kompose /usr/local/bin/
    kompose convert -o deployments.kompose/

    #kubectl create secret generic mssql-secret --from-literal=username='sqladminrDz9621' --from-literal=password='Sql123456'
    kubectl apply -f deployments/mssql-secret.yaml
    kubectl apply -f deployments/env-configmap.yaml
    kubectl apply -f deployments/poi-deployment.yaml

    kubectl get pods
    kubectl exec --stdin --tty poi-f9d9867c4-pq6df -- curl http://localhost/api/poi/healthcheck
