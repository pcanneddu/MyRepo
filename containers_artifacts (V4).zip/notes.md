
# But First, Containers

## Building and Testing

    cp dockerfiles/Dockerfile_0 src/user-java/Dockerfile
    cp dockerfiles/Dockerfile_1 src/tripviewer/Dockerfile
    cp dockerfiles/Dockerfile_2 src/userprofile/Dockerfile
    cp dockerfiles/Dockerfile_3 src/poi/Dockerfile
    cp dockerfiles/Dockerfile_4 src/trips/Dockerfile

    cd src/user-java/
    docker build .
    cd -

    cd src/tripviewer/
    docker build .
    cd -

    cd src/userprofile/
    docker build .
    cd -

    cd src/poi/
    docker build .
    cd -

    cd src/trips/
    docker build .
    cd -

    docker run -e "ACCEPT_EULA=Y" -e "MSSQL_SA_PASSWORD=yourStrongPassword.123" -p 1433:1433 -d mcr.microsoft.com/mssql/server:2017-latest

    docker login registryrdz9621.azurecr.io
    # User  / Password : registryrdz9621 / 3qzLa6AeB6F0QwguQrsmh4ot2OYcYjZ7YMarKXvApx+ACRBbStN/
    docker pull registryrdz9621.azurecr.io/dataload:1.0
    docker run --network <networkname> -e SQLFQDN=mssql -e SQLUSER=sa -e SQLPASS=yourStrongPassword.123 -e SQLDB=mydrivingDB registryrdz9621.azurecr.io/dataload:1.0

    docker compose exec -it mssql /opt/mssql-tools/bin/sqlcmd -S localhost -U sa -P yourStrongPassword.123
    1> CREATE DATABASE mydrivingDB;
    2> GO


    docker compose build
    docker compose up -d --remove-orphans

    curl http://localhost:8080/api/poi/healthcheck
    curl http://localhost:8081/api/trips/healthcheck
    curl http://localhost:8082/api/tripviewer/healthcheck
    curl http://localhost:8083/api/user-java/healthcheck
    curl http://localhost:8084/api/user-profile/healthcheck

    docker compose down -v --remove-orphans
    docker compose push

# Getting Ready for Orchestration

    az login --use-device-code
    sudo az aks install-cli
    az aks get-credentials --resource-group teamResources --name aks

    kubectl version
    kubectl get nodes

    curl -L https://github.com/kubernetes/kompose/releases/download/v1.28.0/kompose-linux-amd64 -o kompose
    chmod a+x kompose
    sudo mv kompose /usr/local/bin/
    kompose convert -o deployments.kompose/

    kubens ns2
    kubectl delete all --all
    #kubectl create secret generic mssql-secret --from-literal=username='sqladminrDz9621' --from-literal=password='Sql123456'
    kubectl apply -f deployments/

    kubectl get pods
    kubectl exec --stdin --tty poi-f9d9867c4-pq6df -- curl http://localhost/api/poi/healthcheck

    kubectl port-forward service/tripviewer 30000:80


# To Orchestration and Beyond

    kubectl delete all --all

    kubectl get clusterroles

    az ad group show --group web-dev --query id -o tsv
    az ad group show --group api-dev --query id -o tsv

    kubectl create rolebinding web-binding --clusterrole=edit --group web-dev --namespace=web
    kubectl create rolebinding api-binding --clusterrole=edit --group api-dev --namespace=api
    kubectl create rolebinding api-binding --clusterrole=read --group api-dev --namespace=web
    kubectl create rolebinding web-binding --clusterrole=read --group web-dev --namespace=api

    kubectl port-forward -n web service/tripviewer 30000:80

    az account set --subscription 22c093fe-6552-48dd-bbad-9110d7c4db32
    az login -u webdev@msftopenhack6880ops.onmicrosoft.com -p "Xoqa6884."
    az aks get-credentials --resource-group teamResources --name aks --context web

    az login -u apidev@msftopenhack6880ops.onmicrosoft.com -p "Fako0170"
    az aks get-credentials --resource-group teamResources --name aks --context api

    kubectx aks
    kubectx web
    kubectx api
